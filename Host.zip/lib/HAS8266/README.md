# HAS8266
Internet of Things (IoT) Home Automation System (HAS) based on ESP8266 with Energy Measurement Capabilities.

- Source Code Repository: https://github.com/dimitarminchev/HAS8266
- Software: Dimitar Minchev, PhD of Informatics, e-mail: mitko@bfu.bg
- Hardware: Atanas Dimitrov, PhD of Robots and manipulators, e-mail: atanas@bfu.bg